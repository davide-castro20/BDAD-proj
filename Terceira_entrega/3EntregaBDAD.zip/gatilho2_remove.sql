drop trigger ChannelSub;
drop trigger SubOwnChannel;